# Privacy Policy

MouseHunt IAP2Gold does not collect, store, or share any user data.

All network requests are made directly from your browser to:
- https://www.mousehuntgame.com/ (to fetch in-game rewards)
- https://api.markethunt.win/ (to fetch public market data)
- https://api.exchangerate-api.com (to fetch currench exchange rate)

No data is sent to any third-party or remote server.
